#ifndef _PCAP_HDR_H
#define _PCAP_HDR_H

#include <stdint.h>

/* See:
 * http://wiki.wireshark.org/Development/LibpcapFileFormat
 */
struct pcap_hdr {
	uint32_t magic_number;	/* magic number */
	uint16_t version_major; /* major version number */
	uint16_t version_minor; /* minor version number */
	uint32_t thiszone;	/* GMT to local correction */
	uint32_t sigfigs;	/* accuracy of timestamps */
	uint32_t snaplen;	/* max length of captured packets, in octets */
	uint32_t network;	/* data link type */
};
struct pcaprec_hdr {
	uint32_t ts_sec;   /* timestamp seconds */
	uint32_t ts_usec;  /* timestamp microseconds */
	uint32_t incl_len; /* number of octets of packet saved in file */
	uint32_t orig_len; /* actual length of packet */
};

#endif
