/* -*- mode: c; c-file-style: "openbsd" -*- */

#include "compat.h"

void
setproctitle(const char *fmt, ...)
{
	/* Do nothing. */
}
