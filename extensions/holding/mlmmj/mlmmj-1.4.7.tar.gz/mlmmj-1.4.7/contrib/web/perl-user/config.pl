$topdir = "/var/spool/mlmmj";
$sendmail = "/usr/lib/sendmail";
$delimiter = "+";
