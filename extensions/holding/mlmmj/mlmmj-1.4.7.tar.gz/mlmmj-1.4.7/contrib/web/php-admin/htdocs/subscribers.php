<?php

/* mlmmj/php-admin:
 * Copyright (C) 2023 Franky Van Liedekerke <franky at e-dynamics dot be>
 * Copyright (C) 2004 Christoph Thiel <ct at kki dot org>
 *
 * mlmmj/php-perl:
 * Copyright (C) 2004 Morten K. Poulsen <morten at afdelingp.dk>
 * Copyright (C) 2004 Christian Laursen <christian@pil.dk>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

require(dirname(dirname(__FILE__))."/conf/config.php");
require(dirname(__FILE__)."/class.rFastTemplate.php");

$tpl = new rFastTemplate($templatedir);

# get the list parameter and check that list exists
if(empty($_GET['list']))
        die("no list specified");
$list = $_GET['list'];

if (dirname(realpath($topdir."/".$list)) != realpath($topdir))
die("list outside topdir");

if(!is_dir($topdir."/".$list))
die("non-existent list");

$userfile = "$topdir/$list/control/subsadmin_users";
if (!is_file($userfile)) {
	$userfile = "$topdir/$list/control/admin_users";
}
$admin_user = "";
if (is_file($userfile)) {
        // read users into array
	$admin_users = array_map('trim',file($userfile));
        // remove empty values from array
        $admin_users = array_filter($admin_users);
        if (!isset($_SERVER['PHP_AUTH_USER']) || !in_array($_SERVER['PHP_AUTH_USER'],$admin_users)) {
                header("WWW-Authenticate: " .
                        "Basic realm=\"Mlmmj Protected Area\"");
                header("HTTP/1.0 401 Unauthorized");
                //Show failure text, which browsers usually
                //show only after several failed attempts
                print("This page is protected by HTTP " .
                        "Authentication.<br>\n");
                exit;
        }
}

$message = "";

# subscribe some people if tosubscribe is set
if (isset($_POST["tosubscribe"])) {
	
	foreach (preg_split('/\r\n|\n|\r/', $_POST["tosubscribe"]) as $line) {
		$email = trim($line);
		if ($email != "") {
			if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$cmd = "/usr/bin/mlmmj-sub -f -q -s -L ".escapeshellarg("$topdir/$list")." -a ".escapeshellarg($email)." 2>&1";
				unset($out);
				exec($cmd, $out, $ret);
				if ($ret !== 0) {
					$message.= "* Subscribe error for $email\ncommand: $cmd\nreturn code: $ret\noutput: ".implode("\n", $out)."\n";
				}
			} else {
				$message.= "* Email address not valid: $email\n";
			}
		}
		
	}

# delete some people if delete is set
} else if (isset($_POST["delete"])) {

	$email = $_POST["email"];
	if (! filter_var($email, FILTER_VALIDATE_EMAIL)) die("Email address not valid");
	
	$cmd = "/usr/bin/mlmmj-unsub -q -s -L ".escapeshellarg("$topdir/$list")." -a ".escapeshellarg($email)." 2>&1";
	unset($out);
	exec($cmd, $out, $ret);
	if ($ret !== 0) {
		$message.= "* Unsubscribe error.\ncommand: $cmd\nreturn code: $ret\noutput: ".implode("\n", $out)."\n";
	}
}

$subscribers="";

# get subscribers from mlmmj
$cmd = "/usr/bin/mlmmj-list -L ".escapeshellarg("$topdir/$list")." |sort";
unset($out);
exec($cmd, $out, $ret);
if ($ret !== 0) {
	$message.= "* Error: Could not get subscribers list.\n";
} else {

	foreach ($out as $email) {
		$email = trim($email);

		$form = "<form action=\"subscribers.php?list=".htmlspecialchars($list)."\" method=\"post\" style=\"margin: 0; margin-left: 1em\">";
		$form.= "<input type=\"hidden\" name=\"email\" value=\"".htmlspecialchars($email)."\" />";
		$form.= "<input type=\"submit\" name=\"delete\" value=\"Remove\" />";
		$form.= "</form>";

		$subscribers.= "<tr><td>".htmlspecialchars($email)."</td><td>$form</td></tr>\n";
	}

	if (empty($subscribers)) {
		$subscribers = "<tr><td>This list is empty or the permissions are not set correctly to get the subscribers.</td></tr>\n";
	}
}

# set template vars
$tpl->define(array("main" => "subscribers.html"));

$tpl->assign(array("LIST" => htmlspecialchars($list)));
$tpl->assign(array("MESSAGE" => "<pre>".htmlspecialchars($message)."</pre>"));
$tpl->assign(array("SUBS" => $subscribers));

$tpl->parse("MAIN","main");
$tpl->FastPrint("MAIN");

?>
