<?php

$topdir = "/var/spool/mlmmj";
$confdir = dirname(__FILE__);
$templatedir = dirname(dirname(__FILE__))."/templates";

?>
