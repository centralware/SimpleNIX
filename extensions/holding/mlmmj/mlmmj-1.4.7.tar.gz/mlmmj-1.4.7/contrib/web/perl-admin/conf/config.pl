$topdir = "/var/spool/mlmmj";
$templatedir = "/home/mlmmj/templates";
