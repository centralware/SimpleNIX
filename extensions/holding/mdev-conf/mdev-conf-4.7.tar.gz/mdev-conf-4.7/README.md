# mdev-conf

Configuration and helper scripts for busybox mdev and mdevd

